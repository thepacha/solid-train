import { GoogleGenAI, Type } from "@google/genai";
import { Criteria, AnalysisResult } from "../types";

// In Vite, env vars must be prefixed with VITE_ and accessed via import.meta.env
// Read the API key lazily at runtime to ensure Vite has loaded env vars
const getApiKey = (): string => {
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY as string | undefined;
  if (!apiKey || apiKey.trim() === '') {
    throw new Error(
      "Missing Gemini API key. Please set VITE_GEMINI_API_KEY in a .env file at the project root and restart the dev server."
    );
  }
  return apiKey;
};

// Lazily create the client so the app can still load even if the key is missing.
const getClient = () => {
  const apiKey = getApiKey();
  return new GoogleGenAI({ apiKey });
};

export const analyzeTranscript = async (
  transcript: string,
  criteria: Criteria[]
): Promise<Omit<AnalysisResult, 'id' | 'timestamp' | 'rawTranscript'>> => {

  const criteriaPrompt = criteria.map(c => `- ${c.name}: ${c.description} (Importance: ${c.weight}/10)`).join('\n');

  const systemInstruction = `
    You are an expert QA Quality Assurance Analyst for Customer Support.
    Your job is to evaluate customer service transcripts based on specific criteria.
    Be strict but fair.
    Identify the Agent and Customer names if possible, otherwise use "Agent" and "Customer".
    Calculate an overall score (0-100) based on the weighted average of the criteria scores.
    Determine the overall customer sentiment.
  `;

  const prompt = `
    Please analyze the following transcript:
    
    "${transcript}"

    Evaluate it against these criteria:
    ${criteriaPrompt}
  `;

  const ai = getClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      systemInstruction: systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          agentName: { type: Type.STRING },
          customerName: { type: Type.STRING },
          summary: { type: Type.STRING },
          overallScore: { type: Type.NUMBER },
          sentiment: { type: Type.STRING, enum: ['Positive', 'Neutral', 'Negative'] },
          criteriaResults: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                score: { type: Type.NUMBER, description: "Score from 0 to 100" },
                reasoning: { type: Type.STRING },
                suggestion: { type: Type.STRING }
              },
              required: ['name', 'score', 'reasoning', 'suggestion']
            }
          }
        },
        required: ['agentName', 'customerName', 'summary', 'overallScore', 'sentiment', 'criteriaResults']
      }
    }
  });

  const resultText = response.text;
  if (!resultText) {
    throw new Error("No response from AI");
  }

  return JSON.parse(resultText) as Omit<AnalysisResult, 'id' | 'timestamp' | 'rawTranscript'>;
};

export const generateMockTranscript = async (): Promise<string> => {
   const ai = getClient();
   const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: "Generate a realistic, slightly problematic customer service chat transcript between a customer (Sarah) and an agent (John) regarding a refund delay. It should be about 10-15 lines long. Do not include markdown formatting, just the text.",
  });
  return response.text || "Agent: Hello, how can I help?\nCustomer: I need a refund.\nAgent: Okay one sec.";
};